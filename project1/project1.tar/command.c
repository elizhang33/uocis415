#include <stdio.h>  /*for getline() system calss*/
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h> /*for mkdir system call*/
#include <dirent.h>
#include <fcntl.h>
#include <errno.h>  /*erro */
#include "command.h"

void listDir() {
    char cwd[1024];
    char *cwdPtr;
    DIR *dirPtr;
    struct dirent *dePtr;
    char *line = NULL;

    if (getcwd(cwd, 1024) != NULL) {
        cwdPtr = getcwd(cwd, 1024);
        dirPtr = opendir(cwdPtr);
        while ((dePtr = readdir(dirPtr)) != NULL) {
                write(1, dePtr->d_name, strlen(dePtr->d_name));
                write(1, "\n", 2);
        }
    }
    free(line);
    closedir(dirPtr);
    return ;
}

void showCurrentDir() {
    char cwd[1024];
    char *cwdPtr;
    if (getcwd(cwd, 1024) != NULL) {
        cwdPtr = getcwd(cwd, 1024);
        write(1, cwdPtr, strlen(cwdPtr));
        write(1, "\n", 2);
    }
}

void makeDir(char *dirName) {
    //if condition check if directory already exists
    if (open(dirName, O_RDONLY) != -1) {
        write(1, "Use a different directory name\n", 31);
    } else {
        mkdir(dirName, 0777);
  }
}

void changeDir(char *dirName){
    //if condition check if directory already exists
      if (open(dirName, O_RDONLY) != -1) {
          chdir(dirName);
          getcwd(dirName, 100);
      } else {
          write(1, "Use a correct directory name\n", 29);
      }
}

void copyFile(char *sourcePath, char *destinationPath){

    int fd;
    int fd2;
    //int src;
    //int dst;
    char buf[BUFSIZ];
    int nread;
    //DIR *src_dir;
    DIR *dst_dir;
    char *filename = NULL;
    char *dst_file = (char*)malloc(strlen(destinationPath) + 1);
    //const char *sign = "/";
    strcpy(dst_file, destinationPath);

    //strrchr
    fd = open(sourcePath, O_RDONLY);
    dst_dir = opendir(destinationPath);
    if (strstr(sourcePath, "/") != NULL) {
        //src_dir = opendir(sourcePath);
        filename = strrchr(sourcePath, '/');
        if (dst_dir == NULL) {
            if (strcmp(filename, destinationPath) != 0) {
              fd2 = open(destinationPath, O_WRONLY | O_CREAT, 0777);
              while ((nread = read(fd, buf, BUFSIZ)) > 0) {
                write(fd2, buf, nread);
              }
              close(fd2);
            } else {
              write(1, "destination path is not valid\n", 30);
            }
        } else {
            //strcat(dst_file, sign);
            strcat(destinationPath, filename);
            fd2 = open(destinationPath, O_WRONLY | O_CREAT, 0777);
            while ((nread = read(fd, buf, BUFSIZ)) > 0) {
              write(fd2, buf, nread);
            }
            closedir(dst_dir);
            close(fd2);
        }

    } else {
        if (dst_dir == NULL) {
            if (strcmp(sourcePath, destinationPath) != 0) {
              fd2 = open(destinationPath, O_WRONLY | O_CREAT, 0777);
              while ((nread = read(fd, buf, BUFSIZ)) > 0) {
                write(fd2, buf, nread);
              }
              close(fd2);
            } else {
                write(1, "destination path is not valid\n", 30);
            }
        } else {
            //strcat(dst_file, sign);
            filename = sourcePath;
            strcat(dst_file, filename);
            fd2 = open(dst_file, O_WRONLY | O_CREAT, 0777);
            while ((nread = read(fd, buf, BUFSIZ)) > 0) {
              write(fd2, buf, nread);
            }
            free(dst_file);
            closedir(dst_dir);
            close(fd2);
        }
    }


    free(dst_file);
    close(fd);
    close(fd2);
    return ;
  }


void moveFile(char *sourcePath, char *destinationPath){
    copyFile(sourcePath, destinationPath);
    deleteFile(sourcePath);
    }


void deleteFile(char *filename){
    unlink(filename);
    }

void displayFile(char *filename){
    int fd;
    char line[1024];
    int oput;

    if ((fd = open(filename, O_RDONLY, 0)) != -1) {
        do {
            oput = read(fd, &line, 1024);
            write(1, line, oput);
        } while (oput > 0);
    } else {
        write(1, "File not exists\n", 16);
        exit(1);
    }
    close(fd);
    return ;
}

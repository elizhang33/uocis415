/*
* Description: in this project, I will implement a pseudo-shell that is
* capable of executing a number of UNIX system commands.
* Author: Xiangqian Zhang
* Date: Oct-3,2020
* Notes:
* 1. <add notes we should consider when grading>
*/

/*-------------------------Preprocessor Directives---------------------------*/
#include <stdio.h>  /*for getline() system calss*/
#include <stdlib.h>
#include <string.h>
#include "command.h"
/*---------------------------------------------------------------------------*/

char *commands[]= {
		"ls", "pwd", "mkdir", "cd", "cp", "mv", "rm", "cat"
};

int in_commands(char *input) {
		for (int i = 0; i < 8; i++) {
			if (strcmp(input, commands[i]) == 0 ) {
				return 1;
			}
	}
	return 0;
}

/*-----------------------------Program Main----------------------------------*/
int main(int argc, char **argv) {
	/* Main Function Variables */
	char arr[] = ">>> ";
	char *line = NULL;
	size_t len = 0;
	char *token = NULL;
	char *line2 = NULL;
	char *token2 = NULL;
	char *token_copy = NULL;

  if (argc == 3 && argv[1][0] == '-' && argv[1][1] == 'f') {
    FILE *file = fopen(argv[2], "r");
		FILE *fpout = freopen ("output.txt", "w", stdout);
    while (getline(&line, &len, file) != -1) {
  		/* Print >>> then get the input string */
  		printf("%s ", arr);
  		printf("\n");

  		line2 = line;
			static char command_line[20][100];
  		while ((token = strtok_r(line2, ";", &line2)) != NULL) {
					int j = 0;
					char *token_copy = token;
					memset(command_line, 0, 100);
					while ((token2 = strtok_r(token_copy, " \n\0", &token_copy)) != NULL) {
							strcpy(command_line[j], token2);
							//printf("%s\n", token2);
							j++;
					}
					if (j > 3) {
						printf("%s\n", "ERROR! Incorrect syntax. No control code found");
					}else {

								if (strcmp(command_line[0], "ls") == 0 ) {
											listDir();
								}
								else if (strcmp(command_line[0], "pwd") == 0) {
									showCurrentDir();
								}
								else if (strcmp(command_line[0], "mkdir") == 0) {
									makeDir(command_line[1]);
								}
								else if (strcmp(command_line[0], "cd") == 0) {
									changeDir(command_line[1]);
								}
								else if (strcmp(command_line[0], "cp") == 0) {
									copyFile(command_line[1], command_line[2]);
								}
								else if (strcmp(command_line[0], "mv") == 0) {
									moveFile(command_line[1], command_line[2]);
								}
								else if (strcmp(command_line[0], "rm") == 0) {
									deleteFile(command_line[1]);
								}
								else if (strcmp(command_line[0], "cat") == 0) {
									displayFile(command_line[1]);
								}
						 else {
								printf("ERROR! Unrecognized command: %s\n", command_line[0]);
							}
						}
						//memset(command_line, 0, 100);
					}
				}
			fclose(file);
			fclose(fpout);
  } else if (argc == 1){
    do {
  		printf("%s ", arr);
  		getline(&line, &len, stdin);
  		printf("\n");

  		line2 = line;
			static char command_line[20][100];
			/*interactive mode will have the input command ends with \0*/
  		while ((token = strtok_r(line2, ";", &line2)) != NULL) {
				int j = 0;
				token_copy = token;
				memset(command_line, 0, 100);
				while ((token2 = strtok_r(token_copy, " \n\0", &token_copy)) != NULL) {
						strcpy(command_line[j], token2);
						j++;

				}
				if (j > 3 || (in_commands(command_line[1]) == 1) /*|| (in_commands(command_line[2]) == 1)*/) {
					printf("%s\n", "ERROR! Incorrect syntax. No control code found");
					break;
				} else {
							if (strcmp(command_line[0], "ls") == 0 ) {
										if (in_commands(command_line[1]) == 0 && j == 2) {
												printf("%s%s\n", "Error! Unsupported parameters for command: ", command_line[0]);
										}else {
												listDir();
											}
							}
							else if (strcmp(command_line[0], "pwd") == 0) {
								if (in_commands(command_line[1]) == 0 && j == 2) {
										printf("%s%s\n", "Error! Unsupported parameters for command: ", command_line[0]);
								}else {
										showCurrentDir();
									}
							}
							else if (strcmp(command_line[0], "mkdir") == 0) {
								if (in_commands(command_line[2]) == 0 && j == 3) {
										printf("%s%s\n", "Error! Unsupported parameters for command: ", command_line[0]);
								}else {
										makeDir(command_line[1]);
									}
							}
							else if (strcmp(command_line[0], "cd") == 0) {
								if (in_commands(command_line[2]) == 0 && j == 3) {
										printf("%s%s\n", "Error! Unsupported parameters for command: ", command_line[0]);
								}else {
										changeDir(command_line[1]);
									}
							}
							else if (strcmp(command_line[0], "cp") == 0) {
								if (in_commands(command_line[3]) == 0 && j == 4) {
										printf("%s%s\n", "Error! Unsupported parameters for command: ", command_line[0]);
								}else if (in_commands(command_line[1]) == 0 && in_commands(command_line[2]) == 0){
										copyFile(command_line[1], command_line[2]);
									}
							}
							else if (strcmp(command_line[0], "mv") == 0) {
										moveFile(command_line[1], command_line[2]);
							}
							else if (strcmp(command_line[0], "rm") == 0) {
								if (in_commands(command_line[2]) == 0 && j == 3) {
										printf("%s%s\n", "Error! Unsupported parameters for command: ", command_line[0]);
								}else if (in_commands(command_line[2]) == 1) {
										printf("%s\n", "ERROR! Incorrect syntax. No control code found");
								}else {
										deleteFile(command_line[1]);
										}
							}
							else if (strcmp(command_line[0], "cat") == 0) {
								if (in_commands(command_line[2]) == 0 && j == 3) {
										printf("%s%s\n", "Error! Unsupported parameters for command: ", command_line[0]);
								} else if (in_commands(command_line[2]) == 1) {
										printf("%s\n", "ERROR! Incorrect syntax. No control code found");
								}else {
										displayFile(command_line[1]);
									}
							}
							else if (strcmp(command_line[0], "exit") == 0) {
								exit(0);
							}
					 else {
							printf("ERROR! Unrecognized command: %s\n", command_line[0]);
						}
					}
					//memset(command_line, 0, 100);
			}
  	} while(1);
  } else if(argc == 2 ) {
      FILE *file = fopen(argv[1], "r");
      if (file != NULL) {
        printf("%s\n", "Add -f before file name for using file mode" );
        fclose(file);
    }else {
        printf("%s\n", "invalid input file" );
    }
  } else {
     printf("%s\n", "Add an input file after -f flag" );
  }

  free(line);

  return 1;
}
/*-----------------------------Program End-----------------------------------*/
